package com.newtonpaiva.dominio;

public class main {
    public static void main(String[] args) {

       var p = new Passageiro(1, "Arthur","arthur26mdias@gmail.com","12345678");
       var b1 = new Bilhete(123,7, "23", "07/10/2023",  "06/10/2023", "comum");
       var b2 = new Bilhete(321,56, "45", "08/10/2023",  "09/10/2023", "comum");
    }
}
